#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jan 25 16:24:24 2023

@author: khazard
"""

import time
import mygraphHierholzer as mg

graphe = {   "A" : {"B","C","F", "E"},
             "B" : {"C", "A", "E"},
             "C" : {"A", "B", "D", "E"},
             "D" : {"C","E"},
             "E" : {"C", "D", "B", "A"},
             "F" : {"A"}
}

""" Disponible dans mygraphHierholzer

def hierholzer(self):
        
        sommet = random.choice(list(self._graphe_dict.keys()))
        print("Le sommet choisi est le sommet : ", sommet)
        
        chemin = []
        chemin.append(sommet)
        
        while(len(self.all_aretes()) > 0):
            voisins = []
            
            for voisin in self.aretes(sommet):
                voisins.append(voisin)
            
            sommet_suivant = self.sommet_suivant(voisins)
            chemin.append(sommet_suivant)
            self.supprime_arrete(sommet, sommet_suivant)
            sommet = sommet_suivant 

        return chemin
        
"""
g=mg.Graphe2(graphe)

print(g.rendEulerien())
print(g.hierholzer())