#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jan 25 15:56:53 2023

@author: efily
"""

"""
Une classe Python pour creer et manipuler des graphes
"""
class Graphe(object):
    def __init__(self, graphe_dict=None):
        """ initialise un objet graphe. Si aucun dictionnaire n'est créé ou donné, on en utilisera un vide"""
        if graphe_dict == None:
            graphe_dict = {}
        self._graphe_dict = graphe_dict
    
    def aretes(self, sommet):
        """ retourne une liste de toutes les aretes d un sommet"""
        list_aretes=[]
        for val in self._graphe_dict[sommet]:
            if self._graphe_dict[sommet] != {}:
                list_aretes.append(set([sommet,val]))
        return list_aretes
    
    
    def all_sommets(self):
        """ retourne tous les sommets du graphe """
        list_s=[]
        for key in self._graphe_dict.keys():
            list_s.append(key)
        return list_s

    def all_aretes(self):
        """ retourne toutes les aretes du graphe
        à partir de la méthode privée,_list_aretes, à définir
        plus bas.
        Ici on fera donc simplement appel à cette méthode.
        """
        return self.__list_aretes()

    def add_sommet(self, sommet):
        """ Si le "sommet" n'set pas déjà présent
        dans le graphe, on rajoute au dictionnaire
        une clé "sommet" avec une liste vide pour valeur.
        Sinon on ne fait rien.
        """
        if sommet not in self._graphe_dict.keys():
            self._graphe_dict[sommet]={}
    
    def add_arete(self, arete):
        """ l'arete est de type set, tuple ou list;
        Entre deux sommets il peut y avoir plus
        d'une arete (multi-graphe)
        """
        for i in arete :
            temp=arete.copy()
            value=self._graphe_dict[i]
            if value != {}:
                value.update(temp)
                value.remove(i)
                self._graphe_dict[i]=value
            else:
                temp.remove(i)
                self._graphe_dict[i]=temp
    
    def rm_arete(self,u,v):
        for v1, cle1 in enumerate(self._graphe_dict[u]):
            
            if cle1 == v:
                self._graphe_dict[u].remove(v)
                break
        for v2, cle2 in enumerate(self._graphe_dict[v]):
            if cle2 == u:
                self._graphe_dict[v].remove(u)
                break
                
    def __list_aretes(self):
        """ Methode privée pour récupérers les aretes.
        Une arete est un ensemble (set)
        avec un (boucle) ou deux sommets."""
        list_a=[]
        for key in self._graphe_dict.keys():
            if self.aretes(key) != []:
                for a in self.aretes(key):
                    list_a.append(a)
        res=[]
        [res.append(x) for x in list_a if x not in res]
        return res
        
    
    def __iter__(self):
        """ on crée un itérable à partir du graphe"""
        self._iter_obj = iter(self._graphe_dict)
        return self._iter_obj
    
    def __next__(self):
        """ Pour itérer sur les sommets du graphe """
        return next(self._iter_obj)
    
    def __str__(self):
        res = "sommets: "
        for k in self._graphe_dict:
            res += str(k) + " "
        res += "\naretes: "
        for arete in self.__list_aretes():
            res += str(arete) + " "
        return res
    
    def trouve_chaine(self, sommet_dep, sommet_arr, chain=None):
        
        chain_copie=[x for x in chain]
        
        chain_copie.append(sommet_dep)
        
        if sommet_dep == sommet_arr:
            return chain_copie
        
        for elem in self._graphe_dict[sommet_dep]:
            if elem not in chain_copie:
                if self.trouve_chaine(elem,sommet_arr,chain_copie) != -1:
                    
                    return self.trouve_chaine(elem,sommet_arr,chain_copie) 
        return -1
    
    
    def trouve_tous_chemins(self, sommet_dep, sommet_arr, chem=[]):
        
        chem= chem + [sommet_dep]
        
        if sommet_dep == sommet_arr:
            return [chem]
        if sommet_dep not in self._graphe_dict.keys():
            return [ ]
        paths = [ ]
        
        for node in self._graphe_dict[sommet_dep]:
            if node not in chem:
                nouv_chem= self.trouve_tous_chemins(node,sommet_arr,chem)
                for k in nouv_chem:
                    paths.append(k)
        return paths
    
        
        
        
    
        

class Graphe2(Graphe):
    def sommet_degre(self, sommet):
        """ renvoie le degre du sommet """
        degre=0
        for elem in self._graphe_dict[sommet]:
            if (elem==sommet):
                degre+=2
            else:
                degre+=1
        return degre
    
    def trouve_sommet_isole(self):
        """ renvoie la liste des sommets isoles """
        isoles=[]
        for elem in self._graphe_dict.keys():
            if (self.sommet_degre(elem)==0):
                isoles.append(elem)
        return isoles
        
    def Delta(self):
        """ le degre maximum """
        maxx=0
        for k in self._graphe_dict.keys():
            if (maxx < self.sommet_degre(k)):
                maxx = self.sommet_degre(k)
        return maxx
    
    def list_degres_croissant(self):
        """ calcule tous les degres et renvoie un tuple de degres decroissant"""
        
        degres=()
        for elem in self._graphe_dict.keys():
           degres= degres + (self.sommet_degre(elem),)
        return sorted(degres,reverse=True)
    
    def list_degres(self):
        """ calcule tous les degres et renvoie un tuple de degres decroissant"""
        
        degres=()
        for elem in self._graphe_dict.keys():
           degres= degres + (self.sommet_degre(elem),)
        return degres
    
        
        
graphe = {"A" :{"C"},
          "B" : {"C", "E"},
          "C" : {"A", "B", "D","E"},
          "D" : {"C"},
          "E" : {"C", "B"},
          "F" : {} } 


graphe2 = {"A" :{"F","D"},
           "B" : {"C"},
           "C" : {"B","C","D","E"},
           "D" : {"A","C","F"},
           "E" : {"C"},
           "F" : {"A","D"} }    

g=Graphe2(graphe)

#g.rm_arete("A", "C")

#g2=Graphe2(graphe2)
#g.add_sommet('A')
#g.add_sommet('V')
#g.add_arete(set(['A','V']))
#print("1",g.aretes('A'))
#print("2",g.aretes('V'))
#print(g.all_aretes())
#print(g.sommet_degre("A"))
#print("#1",g.trouve_chaine("A","Y",""))
#print("#2",g2.trouve_chaine("B","A",""))
#print("#3",g2.trouve_tous_chemins("B","A"))
#print(g2.list_degres())