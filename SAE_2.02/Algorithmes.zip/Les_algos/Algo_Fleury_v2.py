# -*- coding: utf-8 -*-
"""
Created on Sat Mar 25 18:22:56 2023

@author: ewenf
"""

import random
from mygraphFleury import Graphe2 as gr

graphe = {   "A" : {"B","C","F", "E"},
             "B" : {"C", "A", "E"},
             "C" : {"A", "B", "D", "E"},
             "D" : {"C","E"},
             "E" : {"C", "D", "B", "A"},
             "F" : {"A"}
}         

graphe2 = {   "A" : {"B", "E"},
             "B" : {"C", "A", "D"},
             "C" : {"B", "D"},
             "D" : {"C","B"},
             "E" : {"A"},
             "F" : {}
}

g=gr(graphe)
g2=gr(graphe2)


def rendEulerien(graphe):
    D=graphe.trouve_sommet_isole()
    G=graphe.all_sommets()
    # Permet de rendre connexe le graphe en ajoutant des aretes ou sommets isolés avec les sommets qui ont des degrés impair
    if (D != []):
        c=0
        listeDegres=graphe.list_degres()
        for v in listeDegres:
            
            if(v%2!=0 and D != []):
                graphe.add_arete({G[c],D[0]})
                D[0]
                D.pop(0)
            c+=1
    c=0
    listeDegres=graphe.list_degres()
    cache=""
    #rend le graphe eulerien en rendat les degrés des sommets paire 
    for i in range(len(G)):
        if (listeDegres[c] %2 != 0):
            if (cache != ""):
               
                graphe.add_arete({cache,G[c]})
                cache=""
            else:
                cache=G[c]  
        c+=1
    if (all(degres%2 == 0 for degres in graphe.list_degres())==False):
        return "Graphe rendu semi-eulerien"
    
    else:
        return "Graphe rendu eulerien "

    
def pointDeDépart(graphe):
    for d in graphe.list_degres():
        if d%2 != 0:
            return graphe.all_sommets()[graphe.list_degres().index(d)]
        
    else:
        return random.choice(graphe.all_sommets())
        
def dfsCompteur(graphe,v,visiter):
    distance=1
    visiter[graphe.all_sommets().index(v)]=True
    for aretes in graphe.aretes(v):
        # permet de ne pas avoir s dans les voisins
        a = [x for x in list(aretes) if x != v]
        for i in a:
            
            if visiter[graphe.all_sommets().index(i)] == False:
                
                distance += dfsCompteur(graphe, i, visiter)
    return distance

def estUneAreteValide(graphe,u,v):
    #print("u =",u," v=",v)
    if graphe.sommet_degre(u) == 1:
        return True 
    else:
        visiter=[False]*len(graphe.all_sommets())
        compteur1= dfsCompteur(graphe, u, visiter)
        #print("c1--",compteur1)
        graphe.rm_arete(u,v)
     
        visiter=[False]*len(graphe.all_sommets())
        compteur2= dfsCompteur(graphe, u, visiter)
        #print("c2--",compteur2)
        #On rajouter l'arete précédement supprimer
        graphe.add_arete({u,v})
        
        # Si compteur 1 est plus grand, alors l'arete {u, v} est un pont 
        return False if compteur1 > compteur2 else True

def Fleury (graphe, u):
    #print(graphe.all_aretes())
    sommet_adj=[]
    for aretes in graphe.aretes(u):
       a = [x for x in list(aretes) if x != u]
       sommet_adj.append(a[0]) 
    for v in sommet_adj:
        if estUneAreteValide(graphe, u, v):
            print(u,"-->",v,end = ' ')
            graphe.rm_arete(u,v)
            Fleury(graphe, v)
            break
       
    
rendEulerien(g2)
Fleury(g2,pointDeDépart(g2))

