#!/bin/bash

#recupère le chemin absolu pour le volume sur Docker
chemin_absolu=$(readlink -f .)

# Définir le dossier d'images source
echo "Fichier contenant les images à convertir $1"



for photo in './'$1/*.svg
do
 #recupère uniquement le nom et pas le .svg
 nom_img=$(basename "${photo}" | cut -d '.' -sf1)
 
 #commande pour transformer l'image 
 docker container run -v $chemin_absolu:/work bigpapoo/sae103-imagick "convert $photo -shave 45x45 -type grayscale -resize 200x200  './'$1/$nom_img'.png'"

 
done
