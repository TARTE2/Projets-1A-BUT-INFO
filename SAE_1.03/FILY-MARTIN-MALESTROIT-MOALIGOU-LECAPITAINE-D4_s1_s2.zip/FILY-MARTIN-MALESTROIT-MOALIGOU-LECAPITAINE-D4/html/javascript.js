var negatif0 = document.getElementById("Calcul0");
var nb0 = document.getElementById("Calcul0").innerText;
var negatif1 = document.getElementById("Calcul1");
var nb1 = document.getElementById("Calcul1").innerText;
var negatif2 = document.getElementById("Calcul2");
var nb2 = document.getElementById("Calcul2").innerText;
var negatif3 = document.getElementById("Calcul3");
var nb3 = document.getElementById("Calcul3").innerText;

negatif0 = testNum0(nb0); 
negatif1 = testNum1(nb1); 
negatif2 = testNum2(nb2); 
negatif3 = testNum3(nb3); 

function testNum0(a) {
    let result;
    if (a >= 0)
    {
        negatif0.classList.remove("active");
    } else {
        negatif0.classList.add("active");
    }
    return result;
}

function testNum1(a) {
    let result;
    if (a >= 0)
    {
        negatif1.classList.remove("active");
    } else {
        negatif1.classList.add("active");
    }
    return result;
}

function testNum2(a) {
    let result;
    if (a >= 0)
    {
        negatif2.classList.remove("active");
    } else {
        negatif2.classList.add("active");
    }
    return result;
}

function testNum3(a) {
    let result;
    if (a >= 0)
    {
        negatif3.classList.remove("active");
    } else {
        negatif3.classList.add("active");
    }
    return result;
}